# Submission Membangun Aplikasi Catatan Menggunakan React

## Pengantar

Selamat\! Akhirnya Anda telah sampai di penghujung pembelajaran. Anda telah:

* Berkenalan dengan React, mengetahui alasan mempelajari React, dan mengenal ekosistem yang ada di React.
* Belajar tentang konsep dasar React seperti *composition*, *declarative code*, *unidirectional data flow*, dan
  menyadari bahwa React hanyalah JavaScript
* Belajar tentang membangun UI di React seperti mengenal element dan component. Serta, belajar juga konsep component
  properti yang membuat UI aplikasi bersifat *reusable*.
* Belajar tentang *class component*, menggunakan *state* di dalam component, mengubah nilai steta berdasarkan *event
  handling*, serta memahami dan mempraktikkan *controlled component*.

Untuk bisa lulus dan mendapatkan sertifikat dari akademi ini, Anda harus mengerjakan tugas yakni membuat proyek
“Aplikasi Catatan Pribadi” sesuai kriteria yang tertera. Tim Reviewer akan memeriksa pekerjaan Anda dan memberikan reviu
pada proyek yang Anda buat.

## Cara Menggunakan Starter Project

Di dalam kode sumber Anda akan menemukan komentar `TODO` dengan tag `[Basic]`, `[Skilled]`, dan `[Advanced]`. Tag
tersebut mewakili level pada skema **Mastery-Based Grading**. Lengkapi terlebih dahulu seluruh TODO `[Basic]` di setiap
berkas sebelum mencoba level di atasnya. TODO `[Skilled]` dan `[Advanced]` bersifat tantangan lanjutan, pilih sesuai
target nilai Anda.

Seluruh styling (berkas CSS) sudah disediakan. Anda tidak perlu menambahkan atau memodifikasi style agar rubrik apa
pun (termasuk advanced) dapat dinilai dengan baik.

Semua TODO yang wajib diperiksa tercantum di daftar berikut:

* `src/components/App.jsx`
* `src/components/NoteInput.jsx`
* `src/components/NotesList.jsx`
* `src/components/NoteItem.jsx`
* `src/components/NoteSearch.jsx`

Gunakan daftar ini sebagai checklist sebelum melakukan submit.

> **Penting:** Komponen starter telah memiliki atribut `data-testid` pada elemen-elemen kunci untuk kebutuhan
> pengujian otomatis. Jangan menghapus, mengganti nama, atau memindahkan atribut tersebut. Anda boleh menambahkan
> `data-testid` tambahan bila diperlukan, namun nilai yang sudah ada wajib tetap sama agar penilaian dapat berjalan
> mulus.

## Rubrik Mastery-Based Grading

Setiap rubrik mendapat skor 0—3 (Rejected, Basic, Skilled, Advanced). Jika ada rubrik yang berstatus **Rejected**,
submission otomatis ditolak.

### 1. Penguasaan Array Function

* **Rejected**: Komponen `App` tidak menggunakan `Array.prototype.map` maupun `Array.prototype.filter` (UI rusak atau
  daftar tidak berubah).
* **Basic**: `NotesList` merender setiap `NoteItem` menggunakan `map`, dan `onDelete` menghapus catatan dengan `filter`.
* **Skilled**: `App` menerapkan `filter` berdasarkan `searchKeyword` untuk menampilkan daftar hasil pencarian (
  case-insensitive).
* **Advanced**: Catatan dikelompokkan per kombinasi bulan–tahun sebelum dirender; `NotesList` menampilkan struktur
  `<section class="notes-group">` dengan header dan jumlah item untuk tiap grup.

### 2. Reusable Component

* **Rejected**: UI utama ditulis dalam satu komponen sehingga `NotesList` atau `NoteItem` tidak digunakan.
* **Basic**: Komponen starter (`App`, `NoteInput`, `NoteSearch`, `NotesList`, `NoteItem`) tetap terpisah dan data
  dikirim melalui props.
* **Skilled**: Tersedia `src/components/NoteActionButton.jsx` dengan props `variant` dan `onClick` yang dipakai
  `NoteItem` untuk tombol hapus serta arsip.
* **Advanced**: File `src/components/NoteItem.jsx` mendefinisikan fungsi `highlightText` yang mengembalikan elemen
  `<mark>` dan digunakan ulang untuk menyorot `note.title` serta `note.body`.

### 3. State & Event Management

* **Rejected**: Tambah atau hapus catatan tidak mengubah state `notes`.
* **Basic**: `onAdd` menambahkan catatan baru, `onDelete` menghapus catatan dari state, dan pesan kosong muncul saat
  array catatan kosong.
* **Skilled**: `NoteSearch` menyimpan `searchKeyword` di state dan `App` merender daftar yang sudah difilter sesuai kata
  kunci.
* **Advanced**: `onArchive` men-toggle field `archived`, dan UI menampilkan dua section terpisah untuk catatan aktif dan
  arsip lengkap dengan judul `Catatan Aktif` dan `Arsip` beserta jumlah item.

### 4. Controlled Form

* **Rejected**: Nilai input tidak sinkron dengan state atau submit form gagal menambahkan catatan.
* **Basic**: Input judul dan isi merupakan controlled component dan form di-reset setelah submit berhasil.
* **Skilled**: Judul dibatasi maksimal 50 karakter menggunakan state, serta menampilkan counter
  `note-input__title__char-limit` yang berubah dinamis.
* **Advanced**: Submit ditolak apabila isi catatan < 10 karakter; pesan error ditampilkan menggunakan elemen dengan
  class `note-input__feedback--error`.

### Matriks Penilaian

| Rubrik                    | Rejected                                           | Basic                                                                   | Skilled                                                                             | Advanced                                                                                                           |
|---------------------------|----------------------------------------------------|-------------------------------------------------------------------------|-------------------------------------------------------------------------------------|--------------------------------------------------------------------------------------------------------------------|
| Penguasaan Array Function | Tidak ada penggunaan `map`/`filter` yang berfungsi | `map` merender daftar dan `filter` menghapus catatan                    | `filter` menerapkan pencarian berdasarkan `searchKeyword`                           | Daftar dikelompokkan per bulan–tahun dan dirender sebagai `section.notes-group` lengkap dengan header serta jumlah |
| Reusable Component        | UI tidak memanfaatkan komponen modular             | Komponen starter dipakai sesuai tanggung jawab dan menerima props       | Ada `src/components/NoteActionButton.jsx` yang digunakan pada kedua tombol tindakan | `NoteItem` memakai fungsi `highlightText` untuk menghasilkan elemen `<mark>` pada judul dan isi                    |
| State & Event Management  | Operasi CRUD tidak mengubah state                  | Handler tambah/hapus bekerja dan pesan kosong tampil saat daftar kosong | Pencarian mengubah state `searchKeyword` dan daftar yang dirender sudah difilter    | Toggle arsip memindahkan catatan antara section aktif dan arsip, masing-masing dengan judul berisi jumlah          |
| Controlled Form           | Form tidak terkontrol atau submit gagal            | Input judul dan isi controlled, form reset saat submit                  | Judul dibatasi 50 karakter dan counter `note-input__title__char-limit` tersinkron   | Submit ditolak jika isi < 10 karakter dengan pesan `note-input__feedback--error`                                   |

## Referensi *(WIP)*

> **Status:** Bagian referensi masih dalam proses kurasi dan dapat berubah. Gunakan tautan yang tersedia sebagai acuan sementara.

Silakan akses contoh dari [Aplikasi Catatan Pribadi](https://dicoding-react-note-app.netlify.app/) berikut agar Anda
memiliki bayangan seperti apa harus membuat proyek submission-nya. Atau Anda bisa menambahkan tautan video rujukan
favorit Anda sendiri di bagian ini.

Karena di kelas ini kita hanya berfokus pada penggunaan framework React, maka kami telah menyediakan *project starter*
yang di dalamnya berisi kebutuhan dalam menjalankan proyek React, styling dasar, dan data awal catatan yang dibutuhkan.

Silakan unduh *project starter* pada tautan berikut:

* [Starter Project Aplikasi Catatan Pribadi](https://github.com/dicodingacademy/a403-react-pemula-labs/raw/099-shared-files/02-submissions/personal-notes-starter.zip).

Anda bisa memanfaatkan project starter tersebut untuk pengerjaan submission, namun bila tidak pun tidak masalah. Justru,
kami sangat mengapresiasi Anda untuk mengerjakan submission dengan tampilan sekreatif mungkin.

**Catatan:** Jika tidak menggunakan starter project, setidaknya pastikan Anda memanfaatkan initial data yang diberikan
pada starter project tersebut. Initial data berada di berkas *src \-\> utils \-\> index.js*.

## Penilaian *(WIP)*

> **Status:** Mekanisme penilaian berbintang sedang distandardisasi ulang. Informasi di bawah ini bisa diperbarui sewaktu-waktu.

Submission Anda akan dinilai oleh Reviewer dengan skala 1-5. Untuk mendapatkan nilai tinggi, Anda bisa menerapkan
beberapa saran berikut:

* Menerapkan kriteria opsional 1: Terdapat Fitur Pencarian Catatan.
* Menerapkan kriteria opsional 2: Terdapat Limit Karakter pada Input Judul Catatan.
* Menerapkan kriteria opsional 3: Terdapat Fitur Arsip Catatan.
* Menuliskan kode dengan baik:
    * Tidak membuat *class component* yang tidak diperlukan.
    * Memecah UI menjadi komponen sekecil mungkin (sesuai tanggung jawabnya).
    * Gaya penulisan harus kode konsisten.

Berikut adalah detail penilaian submission:

* **Bintang 1** : Semua ketentuan wajib terpenuhi, namun terdapat indikasi kecurangan dalam mengerjakan submission.
* **Bintang 2** : Semua ketentuan wajib terpenuhi, namun terdapat kekurangan pada penulisan kode. Seperti tidak
  menerapkan modularization atau gaya penulisan tidak konsisten.
* **Bintang 3** : Semua ketentuan wajib terpenuhi, namun tidak terdapat improvisasi atau persyaratan opsional yang
  dipenuhi.
* **Bintang 4** : Semua ketentuan wajib terpenuhi dan menerapkan minimal dua saran di atas.
* **Bintang 5** : Semua ketentuan wajib terpenuhi dan menerapkan seluruh saran di atas.

**Catatan:**  
Jika submission Anda ditolak maka tidak ada penilaian. Kriteria penilaian bintang di atas hanya berlaku jika submission
Anda diterima.

## Lainnya

### Ketentuan Berkas Submission

* Berkas submission yang dikirim merupakan folder proyek dari Aplikasi Catatan Pribadi dalam bentuk ZIP.
* Folder yang dikirim merupakan proyek React yang di-*render* menggunakan react-dom bukan react-native.
* Hapus folder *node\_modules* ke dalam berkas ZIP. Karena akan membuat berkas ZIP memiliki ukuran yang besar dan fitur
  code review tidak dapat berfungsi.
* Anda boleh menambahkan berkas aset seperti gambar selama aset tersebut digunakan pada proyek Anda.

### Submission Anda akan Ditolak Bila

* Kriteria utama tidak terpenuhi.
* Ketentuan berkas submission tidak terpenuhi.
* Menggunakan framework atau UI library selain React.
* Mengirimkan kode JavaScript yang telah di-*minify*.
* Melakukan kecurangan seperti tindakan plagiasi.

### Ketentuan Proses Review

Beberapa hal yang perlu Anda ketahui mengenai proses review:

* Tim Reviewer akan mengulas submission Anda dalam waktu selambatnya 3 (tiga) hari kerja *(tidak termasuk Sabtu, Minggu,
  dan hari libur nasional)*.
* Tidak disarankan untuk melakukan submit berkali-kali karena akan memperlama proses penilaian.
* Anda akan mendapatkan notifikasi hasil review submission via email. Status submission juga bisa dilihat dengan
  mengecek di halaman submission.
