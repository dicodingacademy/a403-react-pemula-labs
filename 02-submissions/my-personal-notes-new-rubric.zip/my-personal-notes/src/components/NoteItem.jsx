import React from 'react';
import { showFormattedDate } from '../utils';

function NoteItem({ note, onDelete, onArchive }) {
  return (
    <div
      className="note-item"
      data-testid="note-item"
      data-note-id={note?.id}
    >
      <div className="note-item__content" data-testid="note-item-content">
        {/* TODO [Basic] tampilkan judul catatan menggunakan note.title */}
        {/* TODO [Advanced] sorot kata kunci pencarian dalam judul menggunakan elemen <mark>. */}
        <h3 className="note-item__title" data-testid="note-item-title">
          Judul catatan
        </h3>
        {/* TODO [Basic] gunakan util showFormattedDate untuk menampilkan tanggal dibuat. */}
        <p className="note-item__date" data-testid="note-item-date">
          {showFormattedDate(new Date().toISOString())}
        </p>
        {/* TODO [Basic] tampilkan isi catatan dari note.body */}
        {/* TODO [Advanced] sorot kata kunci pencarian dalam isi menggunakan elemen <mark>. */}
        <p className="note-item__body" data-testid="note-item-body">
          Isi catatan muncul di sini.
        </p>
      </div>
      <div className="note-item__action" data-testid="note-item-action">
        <button
          className="note-item__delete-button"
          type="button"
          // TODO [Basic] panggil onDelete dengan id catatan.
          onClick={() => console.warn('[TODO] Delete note', note.id)}
          data-testid="note-item-delete-button"
        >
          Delete
        </button>
        <button
          className="note-item__archive-button"
          type="button"
          // TODO [Advanced] panggil onArchive dengan id catatan untuk toggle status arsip.
          onClick={() => console.warn('[TODO] Toggle archive', note.id)}
          data-testid="note-item-archive-button"
        >
          {/* TODO [Advanced] ubah label tombol berdasarkan nilai note.archived */}
          Arsipkan
        </button>
        {/* TODO [Skilled] pecah tombol aksi menjadi komponen terpisah */}
      </div>
    </div>
  );
}

export default NoteItem;
